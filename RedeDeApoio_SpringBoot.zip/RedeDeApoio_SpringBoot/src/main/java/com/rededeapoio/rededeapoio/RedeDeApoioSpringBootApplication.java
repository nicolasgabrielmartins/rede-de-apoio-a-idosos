package com.rededeapoio.rededeapoio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RedeDeApoioSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(RedeDeApoioSpringBootApplication.class, args);
	}

}
