package com.rededeapoio.rededeapoio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RedeDeApoioSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
